const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { Skripsi, User } = require('../models');
const auth = require('../middleware/auth');

// Register user
router.post('/register', async (req, res) => {
  try {
    const { nim, nama, password } = req.body;
    const existing = await User.findOne({ where: { nim } });
    if (existing) return res.status(409).json({ message: 'NIM sudah terdaftar' });

    const user = await User.create({ nim, nama, password });
    res.json({ message: 'Registrasi berhasil' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Login user
router.post('/login', async (req, res) => {
  const { nim, password } = req.body;
  const user = await User.findOne({ where: { nim } });

  if (!user) return res.status(404).json({ message: 'NIM tidak ditemukan' });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ message: 'Password salah' });

  const token = jwt.sign({ nim: user.nim, nama: user.nama }, process.env.JWT_SECRET, { expiresIn: '2h' });
  res.json({ token });
});

// Submit skripsi (auth)
router.post('/daftar', auth, async (req, res) => {
  try {
    const { nama, nim, judul, pembimbing } = req.body;
    const pendaftaran = await Skripsi.create({ nama, nim, judul, pembimbing });
    res.json(pendaftaran);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all pendaftar (auth)
router.get('/pendaftar', auth, async (req, res) => {
  const data = await Skripsi.findAll();
  res.json(data);
});

module.exports = router;
